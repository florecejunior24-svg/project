// Dark mode
const root = document.documentElement, themeBtn = document.getElementById('themeBtn');
function setTheme(t){
  root.setAttribute('data-theme', t);
  themeBtn.textContent = t === 'dark' ? 'Light mode' : 'Dark mode';
  try { localStorage.setItem('theme', t); } catch(e){}
}
let saved = null; try { saved = localStorage.getItem('theme'); } catch(e){}
setTheme(saved || 'light');
themeBtn.addEventListener('click', () => setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'));

// Mobile menu
const menuBtn = document.getElementById('menuBtn'), nav = document.getElementById('mainNav');
menuBtn.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', open);
});
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

// Highlight active nav link on scroll
const links = [...document.querySelectorAll('a.nl')];
const io = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) links.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#' + e.target.id));
  });
}, { rootMargin: '-40% 0px -55% 0px' });
links.forEach(l => { const s = document.querySelector(l.getAttribute('href')); if (s) io.observe(s); });
