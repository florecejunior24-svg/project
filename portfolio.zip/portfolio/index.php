<?php
date_default_timezone_set('Asia/Manila');

// ---------- DATA (edit here) ----------
$lastName   = 'FLORECE JR';
$firstName  = 'NESTOR';
$middleName = 'SALES';
$fullName   = "$lastName, $firstName $middleName";
$phone      = '09126721184';
$email      = 'florecejunior24@gmail.com';
$photo      = 'photo.jpg';

$hour = (int) date('G');
if ($hour < 12)      $greeting = 'Good morning';
elseif ($hour < 18)  $greeting = 'Good afternoon';
else                 $greeting = 'Good evening';

// level: 1 to 5
$skills = [
    ['HTML & CSS',        'Builds clean, responsive web pages.',        4],
    ['PHP',               'Basic server-side scripting and dynamic pages.',          3],
    ['JavaScript',        'Interactivity: buttons, toggles, and simple logic.',    3],
    ['MySQL',             'Saving and retrieving data from a database.',              3],
    ['Computer Hardware', 'Troubleshooting and basic computer setup.',           4],
    ['Problem Solving',   'Breaks big problems into small steps.', 4],
];

$projects = [
    ['Personal Portfolio Website', 'This website, built with PHP, HTML, CSS, and JavaScript.', 'PHP · CSS · JS'],
    ['Student Information System', 'Add, edit, delete, and search student records using MySQL.', 'PHP · MySQL'],
    ['Simple Inventory Tracker',   'A list of items with stock counts and low-stock warnings.', 'PHP · MySQL'],
    ['Landing Page Design',        'A responsive landing page for a small business.', 'HTML · CSS'],
];

$formMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n = trim(strip_tags($_POST['name'] ?? ''));
    $e = trim($_POST['email'] ?? '');
    $m = trim(strip_tags($_POST['message'] ?? ''));
    if ($n === '' || $m === '' || !filter_var($e, FILTER_VALIDATE_EMAIL)) {
        $formMsg = 'error';
    } else {
        $sent = @mail($email, "Portfolio message from $n", "Name: $n\nEmail: $e\n\n$m", "From: $e");
        $formMsg = $sent ? 'ok' : 'nomail';
    }
}
function h($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($fullName) ?> | Portfolio</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;700;800&family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>

<aside class="side">
  <a class="brand" href="#home"><?= h($lastName . ' ' . $firstName) ?><small>BSIT student, web developer in training</small></a>
  <button class="menu-toggle" id="menuBtn" aria-expanded="false" aria-controls="mainNav">Menu</button>
  <nav id="mainNav" aria-label="Main">
    <ul>
      <li><a class="nl active" href="#home">Home</a></li>
      <li><a class="nl" href="#about">About Me</a></li>
      <li><a class="nl" href="#skills">Skills</a></li>
      <li><a class="nl" href="#projects">Projects</a></li>
      <li><a class="nl" href="#contact">Contact</a></li>
    </ul>
  </nav>
  <button class="theme-btn" id="themeBtn" type="button">Dark mode</button>
</aside>

<main>
  <section id="home">
    <div class="wrap hero">
      <div>
        <span class="greet"><?= h($greeting) ?>! Welcome to my portfolio.</span>
        <h1><?= h($lastName) ?>, <?= h(ucfirst(strtolower($firstName))) ?> <?= h(substr($middleName, 0, 1)) ?>.</h1>
        <p>Hi, I'm Nestor, a student who is learning how to build websites and software, one project at a time.</p>
        <p>Thanks for stopping by. Have a look around, and feel free to say hello.</p>
        <div class="btns">
          <a class="btn primary" href="#about">About me</a>
          <a class="btn" href="#skills">My skills</a>
          <a class="btn" href="#projects">My projects</a>
          <a class="btn" href="#contact">Contact me</a>
        </div>
      </div>
      <div class="photo">
        <img src="<?= h($photo) ?>" alt="Photo of <?= h($firstName . ' ' . $lastName) ?>">
      </div>
    </div>
  </section>

  <section id="about">
    <div class="wrap">
      <div class="sec-head"><h2>About me</h2></div>
      <div class="about-grid">
        <div>
          <p>I'm <?= h($fullName) ?>, a Filipino IT student who enjoys turning ideas into working websites. I started with simple HTML pages, and now I'm learning PHP and databases to build pages that actually do something.</p>
          <p>I like solving problems step by step, whether it's fixing a bug in my code or troubleshooting a computer. When something doesn't work, I stay with it until I understand why.</p>
          <p>My goal is to become a full-stack web developer and build tools that help people in their daily work.</p>
        </div>
        <ul class="facts">
          <li><b>Name</b><?= h($fullName) ?></li>
          <li><b>Location</b>Philippines</li>
          <li><b>Focus</b>Web development</li>
          <li><b>Currently learning</b>PHP and MySQL</li>
        </ul>
      </div>
    </div>
  </section>

  <section id="skills">
    <div class="wrap">
      <div class="sec-head"><h2>Skills</h2><p>What I can do right now.</p></div>
      <div class="skills">
        <?php foreach ($skills as [$name, $desc, $level]): ?>
          <div class="skill">
            <div class="skill-top">
              <h3><?= h($name) ?></h3>
              <div class="dots" role="img" aria-label="<?= (int)$level ?> out of 5">
                <?php for ($i = 1; $i <= 5; $i++): ?><i class="<?= $i <= $level ? 'on' : '' ?>"></i><?php endfor; ?>
              </div>
            </div>
            <p><?= h($desc) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section id="projects">
    <div class="wrap">
      <div class="sec-head"><h2>Projects</h2><p>Things I built while studying.</p></div>
      <?php foreach ($projects as [$title, $desc, $stack]): ?>
        <article class="proj">
          <h3><?= h($title) ?></h3>
          <span class="stack"><?= h($stack) ?></span>
          <p><?= h($desc) ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  </section>

  <section id="contact">
    <div class="wrap">
      <div class="sec-head"><h2>Contact me</h2><p>Send me a message and I will reply soon.</p></div>
      <div class="contact-grid">
        <div>
          <div class="big"><span>Phone</span><a href="tel:<?= h($phone) ?>"><?= h($phone) ?></a></div>
          <div class="big"><span>Gmail</span><a href="mailto:<?= h($email) ?>"><?= h($email) ?></a></div>
        </div>
        <form method="post" action="#contact">
          <?php if ($formMsg === 'ok'): ?>
            <div class="notice ok">Message sent. Thank you!</div>
          <?php elseif ($formMsg === 'nomail'): ?>
            <div class="notice bad">The message could not be sent. Please try again or email directly.</div>
          <?php elseif ($formMsg === 'error'): ?>
            <div class="notice bad">Please fill in all fields and use a valid email address.</div>
          <?php endif; ?>
          <label for="name">Name</label>
          <input id="name" name="name" type="text" required>
          <label for="email">Email</label>
          <input id="email" name="email" type="email" required>
          <label for="message">Message</label>
          <textarea id="message" name="message" rows="5" required></textarea>
          <button class="btn primary" type="submit">Send message</button>
        </form>
      </div>
    </div>
  </section>
</main>

<footer>&copy; <?= date('Y') ?> <?= h($fullName) ?>. All rights reserved.</footer>

<script src="script.js"></script>
</body>
</html>
